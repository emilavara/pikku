<script>
    export let collectionName
</script>

<a href={`/pikku/${collectionName}`} class="pikku-collection-item">
    {collectionName}
</a>