<script></script>

<div class="pikku-modal">
    <div class="pikku-modal-header">
        <p class="modal-title">Modal title</p>
        <i class="bi bi-x"></i>
    </div>
    <div class="pikku-modal-content">
    </div>
    <div class="pikku-modal-footer">
        <button class="small secondary">Secondary</button>
        <button class="small">Primary</button>
    </div>
</div>