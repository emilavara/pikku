import { writable } from "svelte/store";

export const showCreateCollectionModal = writable(false)
export const showEditFieldModal = writable(false)