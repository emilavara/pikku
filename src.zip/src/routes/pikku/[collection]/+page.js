export function load({ params }) {
    return {
        collection: params.collection
    }
}
